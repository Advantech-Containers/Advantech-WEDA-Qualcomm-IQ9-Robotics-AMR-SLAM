#!/bin/bash
set -e

source "/opt/ros/${ROS_DISTRO}/setup.bash"
source /ws/install/setup.bash


if [ ! -f "${PARAMS_FILE}" ]; then
    DEFAULT_FILE="$(ros2 pkg prefix ros2_wedasubnode_bridge)/share/ros2_wedasubnode_bridge/config/bridge.yaml"
    echo "[entrypoint] ${PARAMS_FILE} not found, using built-in default: ${DEFAULT_FILE}"
    PARAMS_FILE="${DEFAULT_FILE}"
fi

ARGS=(--ros-args --params-file "${PARAMS_FILE}")


if [ -n "${MQTT_HOST}" ]; then ARGS+=(-p "mqtt_host:=${MQTT_HOST}"); fi
if [ -n "${MQTT_PORT}" ]; then ARGS+=(-p "mqtt_port:=${MQTT_PORT}"); fi
if [ -n "${DEVICE_ID}" ]; then ARGS+=(-p "device_id:=${DEVICE_ID}"); fi

echo "[entrypoint] ROS_DOMAIN_ID=${ROS_DOMAIN_ID} RMW_IMPLEMENTATION=${RMW_IMPLEMENTATION:-default}"
echo "[entrypoint] params file: ${PARAMS_FILE}"

exec ros2 run ros2_wedasubnode_bridge bridge_node "${ARGS[@]}"
