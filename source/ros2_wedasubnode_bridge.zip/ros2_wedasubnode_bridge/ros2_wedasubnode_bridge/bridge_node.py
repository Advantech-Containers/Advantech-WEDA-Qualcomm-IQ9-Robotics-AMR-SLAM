import time
from dataclasses import dataclass, field
from typing import List, Optional

import rclpy
from rclpy.exceptions import ParameterUninitializedException
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import (DurabilityPolicy, HistoryPolicy, QoSProfile,
                       ReliabilityPolicy)
from rosidl_runtime_py.utilities import get_message

from ros2_wedasubnode_bridge.mapping import (FieldSpec, iso_timestamp,
                                      parse_field_spec, resolve, to_plain)
from ros2_wedasubnode_bridge.mqtt_client import MultiTopicMqttClient

RELIABILITY = {
    'best_effort': ReliabilityPolicy.BEST_EFFORT,
    'reliable': ReliabilityPolicy.RELIABLE,
}
DURABILITY = {
    'volatile': DurabilityPolicy.VOLATILE,
    'transient_local': DurabilityPolicy.TRANSIENT_LOCAL,
}


@dataclass
class Route:
    name: str
    ros_topic: str
    mqtt_topic: str
    qos: int
    retain: bool
    fields: List[FieldSpec]
    static_fields: dict
    include_envelope: bool
    min_interval: float
    on_change_only: bool
    buffer_latest: bool
    round_decimals: int = -1
    last_sent_time: float = 0.0
    rx_count: int = 0
    tx_count: int = 0
    last_data: Optional[dict] = None
    last_sequence: int = 0


class Ros2MqttBridge(Node):
    def __init__(self) -> None:
        super().__init__('ros2_wedasubnode_bridge')

        self.declare_parameter('device_id', 'robot-01')
        self.declare_parameter('mqtt_host', '127.0.0.1')
        self.declare_parameter('mqtt_port', 1883)
        self.declare_parameter('mqtt_username', '')
        self.declare_parameter('mqtt_password', '')
        self.declare_parameter('mqtt_keepalive', 60)
        self.declare_parameter('bridge_names', Parameter.Type.STRING_ARRAY)

        self._device_id = self._str('device_id')

        self._mqtt = MultiTopicMqttClient(
            host=self._str('mqtt_host'),
            port=self.get_parameter('mqtt_port').value,
            client_id=f'ros2-mqtt-bridge-{self._device_id}',
            logger=self.get_logger(),
            username=self._str('mqtt_username'),
            password=self._str('mqtt_password'),
            keepalive=self.get_parameter('mqtt_keepalive').value,
        )

        self._routes: List[Route] = []
        self._subs = []
        names = self._get('bridge_names') or []
        if not names:
            self.get_logger().warning('bridge_names is empty; nothing to bridge')

        for name in names:
            try:
                self._setup_route(name)
            except Exception as error:  
                self.get_logger().error(f'Bridge "{name}" skipped: {error}')

        self._mqtt.start()
        self.create_timer(5.0, self._report)
        self.get_logger().info(f'Started {len(self._routes)} bridge(s)')

    # ---------- helpers ----------
    def _get(self, name: str):
        """Read parameters; return `None` for unset parameters instead of raising an exception."""
        try:
            return self.get_parameter(name).value
        except ParameterUninitializedException:
            return None

    def _str(self, name: str) -> str:
        value = self._get(name)
        return '' if value is None else str(value)

    def _declare_bridge(self, name: str):
        p = f'bridges.{name}.'
        self.declare_parameter(p + 'enabled', True)
        self.declare_parameter(p + 'ros_topic', '')
        self.declare_parameter(p + 'ros_type', '')
        self.declare_parameter(p + 'mqtt_topic', '')
        self.declare_parameter(p + 'mqtt_qos', 1)
        self.declare_parameter(p + 'mqtt_retain', False)
        self.declare_parameter(p + 'fields', Parameter.Type.STRING_ARRAY)
        self.declare_parameter(p + 'static_fields', Parameter.Type.STRING_ARRAY)
        self.declare_parameter(p + 'include_envelope', True)
        self.declare_parameter(p + 'min_interval_sec', 0.0)
        self.declare_parameter(p + 'on_change_only', False)
        self.declare_parameter(p + 'buffer_latest', False)
        self.declare_parameter(p + 'round_decimals', -1)
        self.declare_parameter(p + 'ros_qos_reliability', 'best_effort')
        self.declare_parameter(p + 'ros_qos_durability', 'volatile')
        self.declare_parameter(p + 'ros_qos_depth', 10)
        return lambda key: self._get(p + key)

    def _setup_route(self, name: str) -> None:
        get = self._declare_bridge(name)

        if not get('enabled'):
            self.get_logger().info(f'Bridge "{name}" disabled')
            return

        ros_topic = (get('ros_topic') or '').strip()
        ros_type = (get('ros_type') or '').strip()
        mqtt_topic = (get('mqtt_topic') or '').strip()
        if not (ros_topic and ros_type and mqtt_topic):
            raise ValueError('ros_topic, ros_type and mqtt_topic are required')

        qos = int(get('mqtt_qos'))
        if qos not in (0, 1, 2):
            raise ValueError('mqtt_qos must be 0, 1 or 2')

        
        parts = ros_type.split('/')
        if len(parts) == 2:
            ros_type = f'{parts[0]}/msg/{parts[1]}'
        msg_class = get_message(ros_type)

        fields = [parse_field_spec(s) for s in (get('fields') or [])]

        static = {}
        for item in (get('static_fields') or []):
            if '=' not in item:
                raise ValueError(f'static_fields entry "{item}" must be key=value')
            k, v = item.split('=', 1)
            static[k.strip()] = v

        reliability = RELIABILITY.get(str(get('ros_qos_reliability')).lower())
        durability = DURABILITY.get(str(get('ros_qos_durability')).lower())
        if reliability is None or durability is None:
            raise ValueError('invalid ros_qos_reliability / ros_qos_durability')

        ros_qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=int(get('ros_qos_depth')),
            reliability=reliability,
            durability=durability,
        )

        route = Route(
            name=name,
            ros_topic=ros_topic,
            mqtt_topic=mqtt_topic.format(device_id=self._device_id),
            qos=qos,
            retain=bool(get('mqtt_retain')),
            fields=fields,
            static_fields=static,
            include_envelope=bool(get('include_envelope')),
            min_interval=float(get('min_interval_sec')),
            on_change_only=bool(get('on_change_only')),
            buffer_latest=bool(get('buffer_latest')),
            round_decimals=int(get('round_decimals')),
        )

        self._subs.append(self.create_subscription(
            msg_class, ros_topic,
            lambda msg, r=route: self._on_message(r, msg),
            ros_qos))
        self._routes.append(route)
        self.get_logger().info(
            f'Bridge "{name}": {ros_topic} [{ros_type}] -> {route.mqtt_topic}')

    # ---------- message handling ----------
    def _on_message(self, route: Route, msg) -> None:
        route.rx_count += 1
        now = time.monotonic()
        if route.min_interval > 0 and now - route.last_sent_time < route.min_interval:
            return

        try:
            data = self._extract(route, msg)

            if route.on_change_only and data == route.last_data:
                return

            payload = self._build_payload(route, msg, data)
            published = self._mqtt.publish(
                route.mqtt_topic, payload, qos=route.qos,
                retain=route.retain, buffer_latest=route.buffer_latest)

            route.last_sent_time = now
            route.last_data = data

            if published:
                route.tx_count += 1
                if route.tx_count == 1:
                    self.get_logger().info(
                        f'[{route.name}] first message published to '
                        f'{route.mqtt_topic}: {payload}')
            elif not route.buffer_latest:
                self.get_logger().warning(
                    f'[{route.name}] MQTT disconnected; message dropped')
        except Exception as error:
            self.get_logger().error(f'[{route.name}] failed to forward: {error}')

    @staticmethod
    def _extract(route: Route, msg) -> dict:
        if not route.fields:
            return {'data': to_plain(msg)}
        data = {}
        for spec in route.fields:
            value = resolve(msg, spec.tokens)
            if spec.func is not None:
                value = spec.func(value)
            if spec.cast is not None:
                value = spec.cast(value)
            if route.round_decimals >= 0 and isinstance(value, float):
                value = round(value, route.round_decimals)
            data[spec.key] = to_plain(value)
        return data

    def _build_payload(self, route: Route, msg, data: dict) -> dict:
        payload = {}
        if route.include_envelope:
            header = getattr(msg, 'header', None)
            sec = header.stamp.sec if header is not None else 0
            nanosec = header.stamp.nanosec if header is not None else 0
            route.last_sequence = max(
                time.time_ns() // 1_000_000, route.last_sequence + 1)
            payload.update({
                'schema_version': 1,
                'device_id': self._device_id,
                'observed_at': iso_timestamp(sec, nanosec),
                'sequence': route.last_sequence,
                'ros_topic': route.ros_topic,
            })
        payload.update(route.static_fields)
        payload.update(data)
        return payload

    def _report(self) -> None:
        """Status is reported every 5 seconds"""
        for r in self._routes:
            if r.rx_count == 0:
                self.get_logger().warning(
                    f'[{r.name}] No messages received from {r.ros_topic} yet '
                    '(Please check the topic name / QoS / ROS_DOMAIN_ID)')
            else:
                self.get_logger().info(
                    f'[{r.name}] ROS received={r.rx_count}, MQTT published={r.tx_count}, '
                    f'MQTT connection={"OK" if self._mqtt.is_connected else "Disconnected"}')


    def destroy_node(self) -> bool:
        self._mqtt.stop()
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = Ros2MqttBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
