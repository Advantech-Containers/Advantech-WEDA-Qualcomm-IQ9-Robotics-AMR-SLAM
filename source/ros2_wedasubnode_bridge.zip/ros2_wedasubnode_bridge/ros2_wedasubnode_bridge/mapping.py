"""Field path resolving and ROS message -> plain JSON-able conversion."""
import math
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, List, Optional, Union

from rosidl_runtime_py.convert import message_to_ordereddict

_TOKEN = re.compile(r'([^.\[\]]+)|\[(-?\d+)\]')


def _to_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ('true', '1', 'yes', 'on')
    return bool(value)


CASTERS = {
    'bool': _to_bool,
    'int': int,
    'float': float,
    'str': str,
}


def _euler(q):
    """Quaternion -> (roll, pitch, yaw) in radians."""
    sinr = 2.0 * (q.w * q.x + q.y * q.z)
    cosr = 1.0 - 2.0 * (q.x * q.x + q.y * q.y)
    sinp = 2.0 * (q.w * q.y - q.z * q.x)
    sinp = max(-1.0, min(1.0, sinp))
    siny = 2.0 * (q.w * q.z + q.x * q.y)
    cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(sinr, cosr), math.asin(sinp), math.atan2(siny, cosy)



FUNCS = {
    'roll_deg': lambda q: math.degrees(_euler(q)[0]),
    'pitch_deg': lambda q: math.degrees(_euler(q)[1]),
    'yaw_deg': lambda q: math.degrees(_euler(q)[2]),                  # -180 ~ 180
    'yaw_deg_360': lambda q: math.degrees(_euler(q)[2]) % 360.0,      # 0 ~ 360
    'yaw_rad': lambda q: _euler(q)[2],
}

_FUNC_CALL = re.compile(r'^(\w+)\((.+)\)$')


@dataclass
class FieldSpec:
    key: str
    tokens: List[Union[str, int]]
    cast: Optional[Callable[[Any], Any]]
    func: Optional[Callable[[Any], Any]] = None


def parse_path(path: str) -> List[Union[str, int]]:
    tokens: List[Union[str, int]] = []
    for m in _TOKEN.finditer(path):
        if m.group(1) is not None:
            tokens.append(m.group(1))
        else:
            tokens.append(int(m.group(2)))
    if not tokens:
        raise ValueError(f'Empty field path: "{path}"')
    return tokens


def parse_field_spec(spec: str) -> FieldSpec:
    """'key=path.to.field:type' -> FieldSpec (':type' and 'key=' optional)."""
    spec = spec.strip()
    if '=' in spec:
        key, path = spec.split('=', 1)
    else:
        path = spec
        key = re.sub(r'[.\[\]]+', '_', spec).strip('_')

    cast = None
    if ':' in path:
        path, type_name = path.rsplit(':', 1)
        type_name = type_name.strip().lower()
        if type_name not in CASTERS:
            raise ValueError(
                f'Unknown type "{type_name}" in "{spec}" '
                f'(use {", ".join(CASTERS)})')
        cast = CASTERS[type_name]

    key = key.strip()
    if not key:
        raise ValueError(f'Empty MQTT key in "{spec}"')

    func = None
    path = path.strip()
    m = _FUNC_CALL.match(path)
    if m:
        func_name, path = m.group(1), m.group(2).strip()
        if func_name not in FUNCS:
            raise ValueError(
                f'Unknown function "{func_name}" in "{spec}" '
                f'(use {", ".join(FUNCS)})')
        func = FUNCS[func_name]

    return FieldSpec(key=key, tokens=parse_path(path), cast=cast, func=func)


def resolve(message: Any, tokens: List[Union[str, int]]) -> Any:
    value = message
    for tok in tokens:
        value = value[tok] if isinstance(tok, int) else getattr(value, tok)
    return value


def to_plain(value: Any) -> Any:
    """Convert ROS values to JSON-safe python values (inf/nan -> None)."""
    if hasattr(value, 'get_fields_and_field_types'):
        return to_plain(message_to_ordereddict(value))
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {k: to_plain(v) for k, v in value.items()}
    if isinstance(value, (bytes, bytearray)):
        return list(value)
    if hasattr(value, 'tolist'):          # numpy arrays
        return to_plain(value.tolist())
    if isinstance(value, (list, tuple)) or type(value).__name__ == 'array':
        return [to_plain(v) for v in value]
    return value


def iso_timestamp(sec: int = 0, nanosec: int = 0) -> str:
    if sec > 0:
        dt = datetime.fromtimestamp(sec + nanosec / 1e9, timezone.utc)
    else:
        dt = datetime.now(timezone.utc)
    return dt.isoformat(timespec='milliseconds').replace('+00:00', 'Z')
