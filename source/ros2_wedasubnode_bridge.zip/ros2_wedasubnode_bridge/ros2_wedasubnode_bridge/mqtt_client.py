import json
from threading import Event, Lock
from typing import Dict, Optional, Tuple

import paho.mqtt.client as mqtt


def _make_client(client_id: str):
    """Create a paho client compatible with both paho 1.x and 2.x."""
    if hasattr(mqtt, 'CallbackAPIVersion'):
        return mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION1,
            client_id=client_id,
            clean_session=True,
            protocol=mqtt.MQTTv311,
        )
    return mqtt.Client(
        client_id=client_id, clean_session=True, protocol=mqtt.MQTTv311)


class MultiTopicMqttClient:
    """MQTT client that can publish to many topics, with reconnect."""

    def __init__(self, host, port, client_id, logger,
                 username='', password='', keepalive=60):
        if not host:
            raise ValueError('MQTT host must not be empty')

        self._host = host
        self._port = port
        self._keepalive = keepalive
        self._logger = logger

        self._connected = Event()
        self._lock = Lock()
        # topic -> (payload, qos, retain); latest value kept for re-publish
        self._buffer: Dict[str, Tuple[str, int, bool]] = {}

        self._client = _make_client(client_id)
        if username:
            self._client.username_pw_set(username, password or None)
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.reconnect_delay_set(min_delay=1, max_delay=30)

    @property
    def is_connected(self) -> bool:
        return self._connected.is_set()

    def start(self) -> None:
        self._logger.info(f'Connecting to MQTT broker {self._host}:{self._port}')
        self._client.connect_async(self._host, self._port, keepalive=self._keepalive)
        self._client.loop_start()

    def stop(self) -> None:
        self._connected.clear()
        try:
            self._client.disconnect()
        finally:
            self._client.loop_stop()
        self._logger.info('MQTT client stopped')

    def publish(self, topic: str, payload: dict, qos: int = 1,
                retain: bool = False, buffer_latest: bool = False) -> bool:
        if not topic.strip():
            raise ValueError('MQTT topic must not be empty')
        if qos not in (0, 1, 2):
            raise ValueError('MQTT QoS must be 0, 1, or 2')

        serialized = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))

        if buffer_latest:
            with self._lock:
                self._buffer[topic] = (serialized, qos, retain)

        if not self.is_connected:
            return False
        return self._publish_raw(topic, serialized, qos, retain)

    def _publish_raw(self, topic, serialized, qos, retain) -> bool:
        result = self._client.publish(topic, serialized, qos=qos, retain=retain)
        if result.rc != mqtt.MQTT_ERR_SUCCESS:
            self._logger.error(f'Failed to queue MQTT message to {topic}: rc={result.rc}')
            return False
        return True

    def _on_connect(self, client, userdata, flags, rc):
        if rc != mqtt.CONNACK_ACCEPTED:
            self._connected.clear()
            self._logger.error(f'MQTT connection rejected: rc={rc}')
            return
        self._connected.set()
        self._logger.info(f'Connected to MQTT broker {self._host}:{self._port}')

        with self._lock:
            pending = dict(self._buffer)
        for topic, (payload, qos, retain) in pending.items():
            self._logger.info(f'Re-publishing buffered message to {topic}')
            self._publish_raw(topic, payload, qos, retain)

    def _on_disconnect(self, client, userdata, rc, *args):
        self._connected.clear()
        if rc == mqtt.MQTT_ERR_SUCCESS:
            self._logger.info('Disconnected from MQTT broker')
        else:
            self._logger.warning(f'MQTT connection lost: rc={rc}; auto-reconnect enabled')
